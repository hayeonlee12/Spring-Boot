package com.codingbox.core4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Core4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
