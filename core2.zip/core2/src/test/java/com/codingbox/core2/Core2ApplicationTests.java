package com.codingbox.core2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Core2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
