package com.codingbox.JPAItem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
