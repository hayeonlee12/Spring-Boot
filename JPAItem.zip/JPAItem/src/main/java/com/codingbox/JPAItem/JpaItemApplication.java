package com.codingbox.JPAItem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaItemApplication.class, args);
	}

}
